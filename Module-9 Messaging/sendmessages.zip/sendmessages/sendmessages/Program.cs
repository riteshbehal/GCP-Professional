﻿using Google.Cloud.PubSub.V1;
using Google.Protobuf;
using Grpc.Core;
using System;
using System.Threading.Tasks;

class Program
{
    static async Task Main(string[] args)
    {
        // Set this to your project and topic
        string projectId = "still-kit-459403-e2";
        string topicId = "first-topic";

        // Create a publisher client
        TopicName topicName = TopicName.FromProjectTopic(projectId, topicId);
        PublisherClient publisher = await PublisherClient.CreateAsync(topicName);

        // The message to publish
        string messageText = "Hello, Pub/Sub!";
        PubsubMessage message = new PubsubMessage
        {
            Data = ByteString.CopyFromUtf8(messageText),
            Attributes =
            {
                { "origin", "dotnet-app" },
                { "timestamp", DateTime.UtcNow.ToString("o") }
            }
        };

        // Publish the message
        string messageId = await publisher.PublishAsync(message);
        Console.WriteLine($"Published message with ID: {messageId}");
    }
}
